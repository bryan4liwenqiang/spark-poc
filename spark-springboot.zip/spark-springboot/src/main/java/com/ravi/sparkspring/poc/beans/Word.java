package com.ravi.sparkspring.poc.beans;

import java.io.Serializable;

public class Word implements Serializable {
    private String word;

    public Word() {
    }

    public Word(String word) {
        this.word = word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public String getWord() {
        return word;
    }
}
